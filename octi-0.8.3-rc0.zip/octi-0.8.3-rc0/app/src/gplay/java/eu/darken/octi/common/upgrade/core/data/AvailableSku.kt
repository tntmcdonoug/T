package eu.darken.octi.common.upgrade.core.data

interface AvailableSku {
    val sku: Sku
}
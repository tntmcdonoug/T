package testhelper

import testhelpers.BaseTestInstrumentation

abstract class BaseUITest : BaseTestInstrumentation()

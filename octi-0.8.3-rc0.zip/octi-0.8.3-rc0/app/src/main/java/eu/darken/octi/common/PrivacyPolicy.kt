package eu.darken.octi.common

object PrivacyPolicy {
    const val URL = "https://github.com/d4rken-org/octi/blob/main/PRIVACY_POLICY.md"
}
package eu.darken.octi.common.lists

interface ListItem
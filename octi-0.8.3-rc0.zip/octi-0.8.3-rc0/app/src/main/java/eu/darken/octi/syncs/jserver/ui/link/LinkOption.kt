package eu.darken.octi.syncs.jserver.ui.link

enum class LinkOption {
    DIRECT,
    QRCODE,
    NFC
}
package eu.darken.octi

object OctiAscii {
    val logo = """
                MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMMMMMMWNNXXXXXNWMMMMMMMMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMWKkoc;'......',:lx0NMMMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMWKo;.                .'lONMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMWOc.                       ,xNMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMKl.                           ;OWMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMM0,                              .xWMMMMMMMMMMMMMM
                MMMMMMMMMMMMMM0,                                .xWMMMMMMMMMMMMM
                MMMMMMMMMMMMMNc      .:loc,.         .;lol:.     ,0MMMMMMMMMMMMM
                MMMMMMMMMMMMMO.    .lXWMMMWO,       ;0WMMMWKc     dWMMMMMMMMMMMM
                MMMMMMMMMMMMMx.    ;XMMMMMMMx.     .OMMMMMMMK,    cNMMMMMMMMMMMM
                MMMMMMMMMMMMMx.    '0WWNNNWNo      .dWWNNNWWk.    cNMMMMMMMMMMMM
                MMMMMMMMMMMMMO.     .:;'.';;.       .;;'.';:.    .dWMMMMMMMMMMMM
                MMMMMMMMMMMMMNc                                  ,0MMMMMMMMMMMMM
                MMMMMMMMMMMMMM0,                                .xWMMMMMMMMMMMMM
                MMMMMMMMMMMMMMM0'                              .xWMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMWx.                             lNMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMWk.                             oNMMMMMMMMMMMMMMM
                MMMMMMMMWXOdllc;.                              .':lloxKWMMMMMMMM
                MMMMMMMXd'                                            .:0WMMMMMM
                MMMMMMNl                                                ,0MMMMMM
                MMMMMMK,                                                .dMMMMMM
                MMMMMMNc               .;,                              'OMMMMMM
                MMMMMMMXo.         .':d0WX:             .:c,.         .;OWMMMMMM
                MMMMMMMMWKxoccclodk0NWMMMM0;             .kNXOxolcccld0NMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMMMMMM0;             lWMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMMMMMMMKc           .xWMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMMMMMMMMNx'.       'xNMMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWX0kocccokXWMMMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
                MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
            """.trimIndent()
}
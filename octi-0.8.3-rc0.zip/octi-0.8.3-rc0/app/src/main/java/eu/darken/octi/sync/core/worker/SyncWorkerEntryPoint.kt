package eu.darken.octi.sync.core.worker

import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn

@InstallIn(SyncWorkerComponent::class)
@EntryPoint
interface SyncWorkerEntryPoint